<?php
namespace Kunnu\Dropbox\Models;

class Thumbnail extends File
{
}
